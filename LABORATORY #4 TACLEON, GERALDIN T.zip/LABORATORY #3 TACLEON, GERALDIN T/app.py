from flask import Flask, render_template, request

app = Flask(__name__, template_folder='templates', static_folder='static')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works', methods=['GET', 'POST'])
def works():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/circle', methods=['GET', 'POST'])
def area_of_circle():
    area = None
    unit = None
    message = ""
    if request.method == 'POST':
        try:
            radius = float(request.form['radius'])
            unit = request.form['unit']
            area = 3.1416 * radius * radius
            message = f"The area of the circle with radius {radius} {unit} is {area:.2f} {unit}²."
        except ValueError:
            message = "Please enter a valid number for radius."
    return render_template('circle.html', message=message)

@app.route('/triangle', methods=['GET', 'POST'])
def area_of_triangle():
    area = None
    unit = None
    message = ""
    if request.method == 'POST':
        try:
            base = float(request.form['base'])
            height = float(request.form['height'])
            unit = request.form['unit']
            area = 0.5 * base * height
            message = f"The area of the triangle with base {base} {unit} and height {height} {unit} is {area:.2f} {unit}²."
        except ValueError:
            message = "Please enter valid numbers for base and height."
    return render_template('triangle.html', message=message)

def infix_to_postfix(expression):
    precedence = {'+':1, '-':1, '*':2, '/':2, '^':3}
    stack = []
    output = ''
    for char in expression:
        if char.isalnum():
            output += char
        elif char == '(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1] != '(':
                output += stack.pop()
            stack.pop()
        else:
            while stack and stack[-1] != '(' and precedence.get(char, 0) <= precedence.get(stack[-1], 0):
                output += stack.pop()
            stack.append(char)
    while stack:
        output += stack.pop()
    return output


@app.route('/infix_to_postfix', methods=['GET', 'POST'])
def infix_to_postfix_page():
    postfix = None
    infix = None
    if request.method == 'POST':
        infix = request.form['infix']
        postfix = infix_to_postfix(infix)
    return render_template('infix_to_postfix.html', infix=infix, postfix=postfix)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/try_infix')
def try_infix():
    return render_template('infix_to_postfix.html')

if __name__ == "__main__":
    app.run(debug=True)
